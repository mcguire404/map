import folium
map3 = folium.Map(location = [33.7809602, -84.3226822], zoom_start = 15, tiles = 'Stamen Terrain')

folium.Marker(location = [33.7809602, -84.3226822], popup = 'I am lost!!', icon=folium.Icon(icon = 'cloud')).add_to(map3)

folium.Marker(location = [33.7809602, -84.3239900], popup = 'I need to go here', icon=folium.Icon(color='green')).add_to(map3)

folium.Marker(location=[33.791827, -84.292222], popup='Store', icon=folium.Icon(icon='star')).add_to(map3)

print(map3.save('map_v3.html'))